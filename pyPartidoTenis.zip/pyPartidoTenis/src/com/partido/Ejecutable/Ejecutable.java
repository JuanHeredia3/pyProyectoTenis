package com.partido.Ejecutable;

import com.partido.Dominio.Jugador;
import com.partido.Dominio.Partido;
import java.util.Scanner;

/**
 *
 * @author Master
 */
public class Ejecutable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        String apellido1 = "", apellido2 = "", nombreTorneo;
        int prob1 = 0, prob2 = 0;
        int cantidadSets;

        Scanner revanchaScanner = new Scanner(System.in);

        try {
            do {
                Scanner scanner = new Scanner(System.in);
                Scanner scanner2 = new Scanner(System.in);

                System.out.println("Ingrese el apellido del primer jugador: ");
                apellido1 = scanner.nextLine();

                System.out.println("Ingrese la probabilidad (1-100) de ganar del primer jugador: ");
                prob1 = scanner.nextInt();

                System.out.println("Ingrese el apellido del segundo jugador: ");
                apellido2 = scanner2.nextLine();

                System.out.println("Ingrese la probabilidad (1-100) de ganar del segundo jugador: ");
                prob2 = scanner2.nextInt();

                if (prob1 + prob2 != 100) {
                    System.out.println("Los porcentajes deben sumar 100 entre ambos!");
                }

            } while (prob1 + prob2 != 100);
        } catch (Exception e) {
            System.out.println("Error! Por favor ingrese bien los datos");
            System.exit(0);
        }

        Scanner scanner3 = new Scanner(System.in);

        System.out.println("Ingrese el nombre del torneo: ");
        nombreTorneo = scanner3.nextLine();

        System.out.println("Ingrese la cantidad de sets a jugar (mejor de 3 o 5): ");
        cantidadSets = scanner3.nextInt();

        int numeroRandom, revancha;
        boolean sumarSet1, sumarSet2, auxPuntos, generarGame1, generarGame2, generarSet1, generarSet2;

        do {
            Jugador jugador1 = new Jugador(apellido1, prob1, 0, 0, 0);
            Jugador jugador2 = new Jugador(apellido2, prob2, 0, 0, 0);

            Partido partido = new Partido(nombreTorneo, cantidadSets);

            if (cantidadSets == 3) {
                while (true) {

                    sumarSet1 = false;
                    sumarSet2 = false;
                    generarGame1 = false;
                    generarGame2 = false;
                    generarSet1 = false;
                    generarSet2 = false;

                    numeroRandom = (int) (Math.random() * 100 + 1);

                    auxPuntos = partido.generarPunto(numeroRandom, prob1);

                    if (auxPuntos) {

                        generarGame1 = partido.definirPunto(jugador1, jugador2);

                        System.out.println(partido.mostrarResultado(jugador1, jugador2));
                        System.out.println(partido.mostrarSaque(jugador1, jugador2));

                    } else {

                        generarGame2 = partido.definirPunto(jugador2, jugador1);

                        System.out.println(partido.mostrarResultado(jugador1, jugador2));
                        System.out.println(partido.mostrarSaque(jugador1, jugador2));
                    }

                    if (generarGame1) {

                        generarSet1 = partido.definirGame(jugador1, jugador2);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    } else if (generarGame2) {

                        generarSet2 = partido.definirGame(jugador2, jugador1);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    }

                    if (generarSet1) {

                        sumarSet1 = partido.sumarSet(jugador1, jugador2);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    } else if (generarSet2) {

                        sumarSet2 = partido.sumarSet(jugador2, jugador1);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    }

                    if (sumarSet1) {
                        break;

                    } else if (sumarSet2) {
                        break;
                    }
                }

                if (sumarSet1) {

                    System.out.println(partido.mostrarGanador(jugador1, jugador2));

                } else if (sumarSet2) {

                    System.out.println(partido.mostrarGanador(jugador2, jugador1));

                }

            } else {
                while (true) {

                    sumarSet1 = false;
                    sumarSet2 = false;
                    generarGame1 = false;
                    generarGame2 = false;
                    generarSet1 = false;
                    generarSet2 = false;

                    numeroRandom = (int) (Math.random() * 100 + 1);

                    auxPuntos = partido.generarPunto(numeroRandom, prob1);

                    if (auxPuntos) {

                        generarGame1 = partido.definirPunto(jugador1, jugador2);

                        System.out.println(partido.mostrarResultado(jugador1, jugador2));
                        System.out.println(partido.mostrarSaque(jugador1, jugador2));

                    } else {

                        generarGame2 = partido.definirPunto(jugador2, jugador1);

                        System.out.println(partido.mostrarResultado(jugador1, jugador2));
                        System.out.println(partido.mostrarSaque(jugador1, jugador2));

                    }

                    if (generarGame1) {

                        generarSet1 = partido.definirGame(jugador1, jugador2);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    } else if (generarGame2) {

                        generarSet2 = partido.definirGame(jugador2, jugador1);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    }

                    if (generarSet1) {

                        sumarSet1 = partido.sumarSet(jugador1, jugador2);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    } else if (generarSet2) {

                        sumarSet2 = partido.sumarSet(jugador2, jugador1);
                        System.out.println(partido.mostrarResultado(jugador1, jugador2));

                    }

                    if (sumarSet1) {
                        break;

                    } else if (sumarSet2) {
                        break;
                    }
                }

                if (sumarSet1) {

                    System.out.println(partido.mostrarGanador(jugador1, jugador2));

                } else if (sumarSet2) {

                    System.out.println(partido.mostrarGanador(jugador2, jugador1));

                }

            }

            do {
                System.out.println("¿Desea la revancha? (1.Sí) (2.No)");
                revancha = revanchaScanner.nextInt();
            } while (revancha != 1 && revancha != 2);

        } while (revancha == 1);

    }

}
