package com.partido.Dominio;

/**
 *
 * @author Master
 */
public class Partido {

    private String nombreTorneo;
    private int cantidadSets, contador = 0;

    public Partido() {
        this.nombreTorneo = "";
        this.cantidadSets = 0;

    }

    public Partido(String nombreTorneo, int cantidadSets) {
        this.nombreTorneo = nombreTorneo;
        this.cantidadSets = cantidadSets;
    }

    public String getNombreTorneo() {
        return nombreTorneo;
    }

    public void setNombreTorneo(String nombreTorneo) {
        this.nombreTorneo = nombreTorneo;
    }

    public int getCantidadSets() {
        return cantidadSets;
    }

    public void setCantidadSets(int cantidadSets) {
        this.cantidadSets = cantidadSets;
    }

    public boolean generarPunto(int numeroRandom, int prob1) {

        return (numeroRandom >= 1 && numeroRandom <= prob1);
    }

    public boolean definirPunto(Jugador jugadorGanador, Jugador jugadorPerdedor) {

        if (jugadorGanador.getGame() == 6 && jugadorPerdedor.getGame() == 6) {

            contador++;

            if (contador == 1) {
                jugadorGanador.setPuntos(0);
                jugadorPerdedor.setPuntos(0);
            }

            jugadorGanador.setPuntos(jugadorGanador.getPuntos() + 1);

            if (jugadorGanador.getPuntos() >= 7 && (jugadorGanador.getPuntos() - jugadorPerdedor.getPuntos() >= 2)) {

                return true;
            } else {

                return false;
            }

        } else {
            switch (jugadorGanador.getPuntos()) {
                case 0:
                    jugadorGanador.setPuntos(jugadorGanador.getPuntos() + 15);
                    break;
                case 15:
                    jugadorGanador.setPuntos(jugadorGanador.getPuntos() + 15);
                    break;
                case 30:
                    jugadorGanador.setPuntos(jugadorGanador.getPuntos() + 10);
                    break;
                case 40:
                    return true;
            }

        }

        return false;
    }

    public boolean definirGame(Jugador jugadorGanador, Jugador jugadorPerdedor) {

        jugadorGanador.setGame(jugadorGanador.getGame() + 1);

        jugadorGanador.setPuntos(0);
        jugadorPerdedor.setPuntos(0);

        if (jugadorGanador.getGame() == 7) {
            return true;
        }

        if (jugadorGanador.getGame() == 6) {

            if (jugadorPerdedor.getGame() == 5) {
                return false;
            }

            if (jugadorPerdedor.getGame() == 6) {
                return false;
            }

            return true;
        }

        return false;

    }

    public boolean sumarSet(Jugador jugadorGanador, Jugador jugadorPerdedor) {

        jugadorGanador.setResultado(jugadorGanador.getGame());
        jugadorPerdedor.setResultado(jugadorPerdedor.getGame());

        jugadorGanador.setSets(jugadorGanador.getSets() + 1);

        jugadorGanador.setPuntos(0);
        jugadorPerdedor.setPuntos(0);

        jugadorGanador.setGame(0);
        jugadorPerdedor.setGame(0);

        if (cantidadSets == 3) {
            if (jugadorGanador.getSets() == 2) {
                return true;
            }

        } else {
            if (jugadorGanador.getSets() == 3 && (jugadorPerdedor.getSets() < 3)) {
                return true;
            }
        }

        return false;
    }

    public String mostrarResultado(Jugador jugador1, Jugador jugador2) {
        StringBuilder aux = new StringBuilder("");

        aux.append("Resultado Parcial:\n")
                .append(nombreTorneo)
                .append("\n")
                .append(jugador1.toString())
                .append("\n")
                .append(jugador2.toString());

        return aux.toString();
    }
    
    public String mostrarSaque(Jugador jugador1, Jugador jugador2){
        
        String aux;
    
        if((jugador1.getGame() + jugador2.getGame()) % 2 == 0){
            
            aux = "Saca " + jugador1.getApellido() + "\n";
        }else{
            aux = "Saca " + jugador2.getApellido() + "\n";
        }
        
        return aux;
    }

    public String mostrarGanador(Jugador jugadorGanador, Jugador jugadorPerdedor) {
        StringBuilder aux = new StringBuilder("");

        aux.append("\n").append(jugadorGanador.getApellido())
                .append(" es el ganador del partido!\n")
                .append("Resultado Final:\n")
                .append(nombreTorneo)
                .append("\n|")
                .append(jugadorGanador.resultadoSets())
                .append("\n|")
                .append(jugadorPerdedor.resultadoSets());

        return aux.toString();

    }

}
