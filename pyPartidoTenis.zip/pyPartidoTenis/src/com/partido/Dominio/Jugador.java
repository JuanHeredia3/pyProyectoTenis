package com.partido.Dominio;

import java.util.ArrayList;

/**
 *
 * @author Master
 */
public class Jugador {

    private String apellido;
    private int probabilidadGanar;
    private int puntos, game, sets;
    private ArrayList<Integer> setsResultados = new ArrayList<>();

    public Jugador() {
        this.apellido = "";
        this.probabilidadGanar = 0;
        this.puntos = 0;
        this.game = 0;
        this.sets = 0;
    }

    public Jugador(String apellido, int probabilidadGanar, int puntos, int sets, int game) {
        this.apellido = apellido;
        this.probabilidadGanar = probabilidadGanar;
        this.puntos = puntos;
        this.game = game;
        this.sets = sets;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getProbabilidadGanar() {
        return probabilidadGanar;
    }

    public void setProbabilidadGanar(int probabilidadGanar) {
        this.probabilidadGanar = probabilidadGanar;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public int getSets() {
        return sets;
    }

    public void setSets(int sets) {
        this.sets = sets;
    }

    public int getGame() {
        return game;
    }

    public void setGame(int game) {
        this.game = game;
    }

    public void setResultado(Integer setResultado) {
        this.setsResultados.add(setResultado);
    }

    public String resultadoSets() {
        StringBuilder x = new StringBuilder(apellido);
        
        x.append("\t");
        
        for (Integer setResultado : this.setsResultados) {
            x.append("|").append(setResultado.toString());
        }

        return x.toString();
    }

    @Override
    public String toString() {
        return "|" + apellido + "\t" + puntos + "|" + game + "| "+ sets + "|";
    }

}
